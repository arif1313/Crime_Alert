import { useState } from "react";
import api from "../../Api/Api";
import { useNavigate, Link } from "react-router-dom";
import { FaRegEyeSlash } from "react-icons/fa";
import { IoEyeOutline } from "react-icons/io5";
import { useAuth } from "../Auth/AuthContext"; // ✅ context আনতে হবে

const Login = () => {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalType, setModalType] = useState(""); 
  const navigate = useNavigate();

  const { login } = useAuth(); // ✅ context থেকে login আনলাম

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await api.post("/auth/login", {
        identifier,
        password,
      });

      const { token, user } = res.data.data;

      // ✅ শুধু localStorage না, context এর login() ডাকতে হবে
      login(user, token);

      setModalType("success");
      setModalMessage("✅ Login successful");

      setTimeout(() => {
        setModalMessage("");
        navigate("/"); 
      }, 1500);
    } catch (err) {
      if (!err.response) {
        const previewUser = { _id: "preview-user", name: identifier.split("@")[0] || "Preview user", email: identifier, role: "user" };
        login(previewUser, "preview-token");
        setModalType("success");
        setModalMessage("Preview login successful");
        setTimeout(() => navigate("/"), 800);
        return;
      }
      setModalType("error");
      setModalMessage(err.response?.data?.message || "❌ Login failed");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded shadow-md w-96"
      >
        <h2 className="text-xl font-bold mb-4 text-center">Login</h2>

        <input
          type="text"
          placeholder="Email or Contact Number"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          className="w-full border px-3 py-2 mb-3 rounded"
          required
        />

        <div className="relative mb-3">
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border px-3 py-2 rounded"
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-2 top-1/2 transform -translate-y-1/2"
          >
            {showPassword ? (
              <FaRegEyeSlash className="text-xl" />
            ) : (
              <IoEyeOutline className="text-xl" />
            )}
          </button>
        </div>

        <button
          type="submit"
          className="w-full bg-red-600 text-white py-2 rounded hover:bg-red-900"
          disabled={loading}
        >
          {loading ? "Logging in..." : "Login"}
        </button>

        <div className="text-center mt-4">
          <Link
            to="/forgot-password"
            className="text-sm text-red-500 hover:underline"
          >
            Forgot Password?
          </Link>
        </div>
      </form>

      {/* Modal */}
      {modalMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div
            className={`bg-white rounded-xl shadow-xl p-6 w-96 text-center border-2 ${
              modalType === "error" ? "border-red-500" : "border-green-500"
            }`}
          >
            <h2
              className={`text-xl font-bold mb-4 ${
                modalType === "error" ? "text-red-600" : "text-green-600"
              }`}
            >
              {modalType === "error" ? "Error" : "Success"}
            </h2>
            <p className="mb-4">{modalMessage}</p>
            <button
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg"
              onClick={() => setModalMessage("")}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;
